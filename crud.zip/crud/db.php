<?php 
$localhost = "localhost";
$un = "root";
$pass = "";
$dbname = "api2";
$con = mysqli_connect($localhost, $un, $pass, $dbname);

?>